package org.artofsolving.jodconverter.converttask;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.artofsolving.jodconverter.document.DocumentFormat;
import org.artofsolving.jodconverter.util.ConvertUtils;


public class ConvertRunnable implements Runnable {

  private Logger logger = Logger.getLogger( ConvertRunnable.class );
  public static boolean isStop = true;

  public static void main( String[] args ) {

    new Thread( new Runnable() {

      @Override
      public void run() {

      }

    } ).start();

  }

  @Override
  public void run() {
    ConvertTaskQueueManager m = ConvertTaskQueueManager.getInstance();

    while ( true ) {
      try {
        Thread.sleep( 2000 );
      }
      catch ( InterruptedException e ) {
        e.printStackTrace();
      }
      System.out.println( "Convert Thread is Running..." );
      if ( !ConvertRunnable.isStop || m.get() == null ) {
        continue;
      }
      ConvertRunnable.isStop = false;
      System.out.println( "New Convert Task Start." );
      new ConvertUtils() {

        protected File getOutoutFile( File inputFile, DocumentFormat outputFormat ) {
          File outputFile = null;
          try {
            outputFile = File.createTempFile( inputFile.getName().substring( 0, inputFile.getName().indexOf( "." ) ), "." + outputFormat.getExtension(),
                inputFile.getParentFile() );
          }
          catch ( IOException e ) {
            e.printStackTrace();
          }
          return outputFile;
        }

        protected boolean processFile( File inputFile, File outputFile, DocumentFormat outputFormat ) {
          if ( !m.get().getOutFileDir().exists() ) {
            m.get().getOutFileDir().mkdirs();
          }
          outputFile.renameTo( new File( m.get().getOutFileDir(), inputFile.getName().substring( 0, inputFile.getName().lastIndexOf( "." ) ) + "." + outputFormat.getExtension() ) );
          return true;
        }
      }.convertFile2PDF( m.get().getTaskContent() );
      ConvertRunnable.isStop = true;
      m.remove();
      System.out.println( "New Convert Task End." );
    }
  }
}
