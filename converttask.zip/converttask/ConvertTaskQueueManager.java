package org.artofsolving.jodconverter.converttask;

import java.util.concurrent.PriorityBlockingQueue;


public class ConvertTaskQueueManager {

  private static ConvertTaskQueueManager instance;

  private PriorityBlockingQueue<ConvertTask> queue = new PriorityBlockingQueue<ConvertTask>();

  public static ConvertTaskQueueManager getInstance() {
    if ( instance == null ) {
      instance = new ConvertTaskQueueManager();
    }
    return instance;
  }

  public boolean add( ConvertTask task ) {
    return queue.offer( task );
  }

  public ConvertTask remove() {
    return queue.poll();
  }

  public ConvertTask get() {
    return queue.peek();
  }

  public int size() {
    return queue.size();
  }
}
