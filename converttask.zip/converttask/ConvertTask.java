package org.artofsolving.jodconverter.converttask;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;


public class ConvertTask implements Comparable<ConvertTask> {

  private String taskId;
  private long taskCreateTime;
  private int priority = Integer.MAX_VALUE;
  private File[] taskContent;
  private File outFileDir;

  public ConvertTask( String taskId, long taskCreateTime, int priority, File[] taskContent ) {
    super();
    this.taskId = taskId;
    this.taskCreateTime = taskCreateTime;
    this.priority = priority;
    this.taskContent = taskContent;
  }

  public String getTaskId() {
    return taskId;
  }

  public void setTaskId( String taskId ) {
    this.taskId = taskId;
  }

  public long getTaskCreateTime() {
    return taskCreateTime;
  }

  public void setTaskCreateTime( long taskCreateTime ) {
    this.taskCreateTime = taskCreateTime;
  }

  public int getPriority() {
    return priority;
  }

  public void setPriority( int priority ) {
    this.priority = priority;
  }

  public File[] getTaskContent() {
    return taskContent;
  }

  public void setTaskContent( File[] taskContent ) {
    this.taskContent = taskContent;
  }

  @Override
  public int compareTo( ConvertTask o ) {
    if ( o.getPriority() > this.priority ) {
      return -1;
    }
    else if ( o.getPriority() == this.priority ) {
      if ( o.getTaskCreateTime() > this.taskCreateTime ) {
        return -1;
      }
      else if ( o.getTaskCreateTime() == this.taskCreateTime ) {
        return 0;
      }
      else {
        return 1;
      }
    }
    else {
      return 1;
    }
  }

  public File getOutFileDir() {
    return outFileDir;
  }

  public void setOutFileDir( File outFileDir ) {
    this.outFileDir = outFileDir;
  }
  
  public static void main(String[] args){
    try{
      Integer a = null;
      a.toString();
    }catch(Throwable t){
      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);
      t.printStackTrace(pw);
      System.out.println(sw.toString());
    }
  }

}
