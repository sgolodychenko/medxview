package org.artofsolving.jodconverter.converttask;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Date;
import java.util.UUID;


public class ConvertTest {

  public static void main( String[] args ) {

    new Thread( new Runnable() {

      ConvertTaskQueueManager m = ConvertTaskQueueManager.getInstance();

      @Override
      public void run() {
        while ( true ) {
          try {
            Thread.sleep( 1000 );
          }
          catch ( InterruptedException e ) {
            e.printStackTrace();
          }
          File dir = new File( "D:\\TEST\\2" );
          File outDir = new File( "D:\\TEST\\C" );
          File[] files = dir.listFiles( new FilenameFilter() {

            public boolean accept( File dir, String name ) {
              return !name.startsWith( "." );
            }
          } );
          if ( files.length > 0 ) {
            ConvertTask task1 = new ConvertTask( UUID.randomUUID().toString().replace( "-", "" ), new Date().getTime(), Integer.MAX_VALUE, files );
            task1.setOutFileDir( outDir );
            if ( !hasExsitInQ( files ) ) {
              m.add( task1 );
            }

          }
        }
      }

    } ).start();
    new Thread( new ConvertRunnable() ).start();
    new Thread( new Runnable() {

      @Override
      public void run() {
        while ( true ) {
          try {
            Thread.sleep( 1 * 1000 * 60 );
            
          }
          catch ( InterruptedException e ) {
            e.printStackTrace();
          }
        }
      }

    } ).start();
  }

  private static boolean hasExsitInQ( File[] cf ) {
    ConvertTaskQueueManager m = ConvertTaskQueueManager.getInstance();
    for ( int i = 0; i < m.size(); i++ ) {
      if ( isSameTaskContent( m.get().getTaskContent(), cf ) ) { return true; }
    }
    return false;
  }

  private static boolean isSameTaskContent( File[] qt, File[] ct ) {
    if ( qt.length > 0 && ct.length > 0 ) {
      for ( int i = 0; i < qt.length; i++ ) {
        if ( qt[i].getAbsolutePath().equals( ct[i].getAbsolutePath() ) ) return true;
      }
    }
    return false;
  }

}
